package com.example.proyekakhir_kelompok4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;

import java.util.ArrayList;

public class HorrorActivity extends AppCompatActivity {
    private RecyclerView rvBooklist;
    private RecyclerView.Adapter booklistAdapter;
    private RecyclerView.LayoutManager layoutManager;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_horror);
        ArrayList<ArrayItems> booklist = new ArrayList<>();
        booklist.add(new ArrayItems(R.drawable.horror_holymother, R.drawable.rating4, "Holy Mother", "Akiyoshi Rikako", "Rp 85.000"));
        booklist.add(new ArrayItems(R.drawable.horror_pestabunuhdiri, R.drawable.rating, "Pesta Bunuh Diri", "Daniel Ahmad", "Rp 99.000"));
        booklist.add(new ArrayItems(R.drawable.horror_jurnalrisa, R.drawable.rating, "Jurnal Risa: Teror Liburan Sekolah", "Risa Saraswati", "Rp 82.500"));
        booklist.add(new ArrayItems(R.drawable.horror_sesuk, R.drawable.rating, "Sesuk", "Tere Liye", "Rp 89.000"));
        booklist.add(new ArrayItems(R.drawable.horror_wingit, R.drawable.rating, "Wingit", "Sara Wijayanto", "Rp 100.000"));
        booklist.add(new ArrayItems(R.drawable.horror_sewudino, R.drawable.rating4, "Sewu Dino", "Simpleman", "Rp82.500"));
        booklist.add(new ArrayItems(R.drawable.horror_kisahtanahjawapocong, R.drawable.rating, "Kisah Tanah Jawa: Pocong Gundul", "@kisahjanahjawa", "Rp 66.000"));
        booklist.add(new ArrayItems(R.drawable.horror_keluargatakkasatmata, R.drawable.rating, "Keluarga Tak Kasat Mata", "Bonaventura Genta", "Rp 55.000"));

        rvBooklist = findViewById(R.id.rv);
        rvBooklist.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        booklistAdapter = new BooklistAdapter(booklist);

        rvBooklist.setLayoutManager(layoutManager);
        rvBooklist.setAdapter(booklistAdapter);
    }
}