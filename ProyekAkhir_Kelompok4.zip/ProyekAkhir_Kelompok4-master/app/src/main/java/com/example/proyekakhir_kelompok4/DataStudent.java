package com.example.proyekakhir_kelompok4;

public class DataStudent {
    public String username;
    public String nim;
    public String prodi;
    public String fakultas;

    public DataStudent(String username, String nim, String prodi, String fakultas){
        this.username = username;
        this.nim = nim;
        this.prodi = prodi;
        this.fakultas = fakultas;
    }
}
