package com.example.proyekakhir_kelompok4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;

import java.util.ArrayList;

public class EdukasiActivity extends AppCompatActivity {
    private RecyclerView rvBooklist;
    private RecyclerView.Adapter booklistAdapter;
    private RecyclerView.LayoutManager layoutManager;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edukasi);
        ArrayList<ArrayItems> booklist = new ArrayList<>();
        booklist.add(new ArrayItems(R.drawable.edukasi_belajarcoding, R.drawable.rating4, "Belajar Coding: Algoritma Dan Bug", "Elizabeth Tweedale", "Rp 40.000"));
        booklist.add(new ArrayItems(R.drawable.edukasi_html5danphp, R.drawable.rating4, "Html 5 & Php", "Jubilee Enterprise", "Rp 49.000"));
        booklist.add(new ArrayItems(R.drawable.edukasi_logikapemrogramanjava, R.drawable.rating4, "Logika Pemrograman Java", "Abdul Kadir", "Rp 49.000"));
        booklist.add(new ArrayItems(R.drawable.edukasi_dasarpemrogramandenganphyton, R.drawable.rating4, "Dasar-Dasar Pemrograman dengan Python", "Wenty Dwi Yuniarti", "Rp 79.000"));
        booklist.add(new ArrayItems(R.drawable.edukasi_pemrogramanphytonuntukpenangananbigdata, R.drawable.rating, "Pemrograman Python untuk Penanganan Big Data", "Hanna Arini Parhusip", "Rp 62.000"));
        booklist.add(new ArrayItems(R.drawable.edukasi_privatalfaiz, R.drawable.rating, "Privat Al Faiz Sukses SKD CPNS 2023", "Al Faiz", "Rp 123.250"));
        booklist.add(new ArrayItems(R.drawable.edukasi_bukupersuasive, R.drawable.rating4, "Buku Persuasive Copywriting: Sebuah Seni Menjual Melalui Tulisan (2020)", "Febri Asiani", "Rp 100.000"));

        rvBooklist = findViewById(R.id.rv);
        rvBooklist.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        booklistAdapter = new BooklistAdapter(booklist);

        rvBooklist.setLayoutManager(layoutManager);
        rvBooklist.setAdapter(booklistAdapter);
    }
}