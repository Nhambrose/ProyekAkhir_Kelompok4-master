package com.example.proyekakhir_kelompok4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class ListBuku extends AppCompatActivity {

    private RecyclerView rvBooklist;
    private RecyclerView.Adapter booklistAdapter;
    private RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_buku);

        ArrayList<ArrayItems> booklist = new ArrayList<>();
        booklist.add(new ArrayItems(R.drawable.jjk, R.drawable.rating, "Jujutsu Kaisen", "Adventure of Spirit", "Rp. 10.000"));
        booklist.add(new ArrayItems(R.drawable.marin, R.drawable.rating, "My DressUp Darling", "Kitagawa Marin's Lovestory", "Rp. 5.000"));
        booklist.add(new ArrayItems(R.drawable.zerotwo, R.drawable.rating, "Darling in Franxx", "Eternal Love", "Rp. 150.000"));

        rvBooklist = findViewById(R.id.rv_booklist);
        rvBooklist.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        booklistAdapter = new BooklistAdapter(booklist);

        rvBooklist.setLayoutManager(layoutManager);
        rvBooklist.setAdapter(booklistAdapter);
    }
}