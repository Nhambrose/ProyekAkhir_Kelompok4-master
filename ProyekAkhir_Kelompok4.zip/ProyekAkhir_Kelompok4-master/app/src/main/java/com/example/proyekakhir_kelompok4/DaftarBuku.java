package com.example.proyekakhir_kelompok4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class DaftarBuku extends AppCompatActivity {

    private RecyclerView rvBooklist;
    private RecyclerView.Adapter booklistAdapter;
    private RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_buku);
        ArrayList<ArrayItems> booklist = new ArrayList<>();
        booklist.add(new ArrayItems(R.drawable.jjk, R.drawable.rating, "Jujutsu Kaisen", "Adventure of Spirit", "Rp. 10.000"));
        booklist.add(new ArrayItems(R.drawable.marin, R.drawable.rating, "My DressUp Darling", "Kitagawa Marin's Lovestory", "Rp. 5.000"));
        booklist.add(new ArrayItems(R.drawable.zerotwo, R.drawable.rating, "Darling in Franxx", "Eternal Love", "Rp. 150.000"));
        booklist.add(new ArrayItems(R.drawable.anime_deathnote, R.drawable.rating, "Death Note Short Stories", "Tsugumi Ohba", "Rp. 39.000"));
        booklist.add(new ArrayItems(R.drawable.anime_bluelock, R.drawable.rating, "Blue Lock 01", "Muneyuki Kaneshiro dan Yusuke Nomura", "Rp. 40.000"));
        booklist.add(new ArrayItems(R.drawable.anime_tokyorevengers, R.drawable.rating4, "Tokyo Revengers 01", "Ken Wakui", "Rp. 35.000"));
        booklist.add(new ArrayItems(R.drawable.zerotwo, R.drawable.rating, "Shaman King Complete Edition 03", "Hiroyuki Takei", "Rp. 45.000"));

        rvBooklist = findViewById(R.id.recview_booklist);
        rvBooklist.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        booklistAdapter = new BooklistAdapter(booklist);

        rvBooklist.setLayoutManager(layoutManager);
        rvBooklist.setAdapter(booklistAdapter);
    }
}