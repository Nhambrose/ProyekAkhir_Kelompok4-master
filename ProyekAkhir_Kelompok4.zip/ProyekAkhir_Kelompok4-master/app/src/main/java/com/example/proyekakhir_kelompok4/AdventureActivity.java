package com.example.proyekakhir_kelompok4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class AdventureActivity extends AppCompatActivity {
    private RecyclerView rvBooklist;
    private RecyclerView.Adapter booklistAdapter;
    private RecyclerView.LayoutManager layoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adventure);
        ArrayList<ArrayItems> booklist = new ArrayList<>();
        booklist.add(new ArrayItems(R.drawable.adventure_titiknol, R.drawable.rating4, "Titik Nol", "Agustinus Wibowo", "Rp 130.000"));
        booklist.add(new ArrayItems(R.drawable.adventure_pangerancilik, R.drawable.rating4, "Pangeran Cilik: Le Petit Prince", "Antoine de Saint Exupery", "Rp 58.000"));
        booklist.add(new ArrayItems(R.drawable.adventure_tansebuahnovel, R.drawable.rating4, "Tan : Sebuah Novel", "Hendri Teja", "Rp 71.900"));
        booklist.add(new ArrayItems(R.drawable.adventure_perjalananmustahilsamiamdarilisboa, R.drawable.rating4, "Perjalanan Mustahil dari Lisboa", "Zaki Yamani", "Rp 97.000"));
        booklist.add(new ArrayItems(R.drawable.adventure_arahlangkah, R.drawable.rating, "Arah Langkah", "Fiersa Besari", "Rp 88.000"));
        booklist.add(new ArrayItems(R.drawable.adventure_sangalkemis, R.drawable.rating4, "Sang Alkemis", "Paulo Coelho", "Rp 65.000"));
        booklist.add(new ArrayItems(R.drawable.adventure_mencarinamatuhanyangkeseratus, R.drawable.rating4, "Mencari Nama Tuhan yang Keseratus", "Amin Maalouf", "Rp 120.000"));
        booklist.add(new ArrayItems(R.drawable.adventure85cm, R.drawable.rating, "5 cm: Aku, Kamu, Samudera, dan Bintang-Bintang", "Donny Dhirgantoro", "Rp 115.000"));

        rvBooklist = findViewById(R.id.rv);
        rvBooklist.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        booklistAdapter = new BooklistAdapter(booklist);

        rvBooklist.setLayoutManager(layoutManager);
        rvBooklist.setAdapter(booklistAdapter);
    }
}