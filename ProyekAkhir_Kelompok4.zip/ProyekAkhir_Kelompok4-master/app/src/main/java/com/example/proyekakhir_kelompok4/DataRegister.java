package com.example.proyekakhir_kelompok4;

public class DataRegister {
    public String username;

    public DataRegister(){

    }

    public DataRegister(String username) {
        this.username = username;
    }

}
